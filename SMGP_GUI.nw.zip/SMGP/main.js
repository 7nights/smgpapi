(function(){
  'use strict';
  
  var exec = require('child_process').exec,
      spawn = require('child_process').spawn;

  var config = {
    "smgwip" : "127.0.0.1",
    "smgwport" : "8890",
    "smgwaccount" : "phone1",
    "smgwpasswd" : "123456",
    "smgwspid" : "12100136",
    "smgpspnum" : "18900000001",
    "destnum" : "18900000002",
    "content" : "How are you?"
  },
  combineConfig = function(c){
    var str = "";
    for(var key in c){
      str += ("-" + key + " " + c[key]);
      str += " ";
    }
    return str;
  },
  chooseAccount = function(account){
    switch(account){
      case "phone1":
        config.smgwaccount = "phone1";
        config.smgpspnum = "18900000001";
        break;
      case "phone2":
        config.smgwaccount = "phone2";
        config.smgpspnum = "18900000002";
        break;
      case "phone3":
        config.smgwaccount = "phone3";
        config.smgpspnum = "18900000003";
        break;
    }
  };

  function sendMessage(msg, to){
    config.content = '"' + msg.replace(/"/g, '\\"') + '"';
    config.destnum = to;
    var child = exec('java -classpath ./lib/smgpapi20100109.jar Sample.SendSms ' + combineConfig(config), function(err, out, stderr){
        if(err !== null) console.log("exec error: ", err);
        child.kill();
        child = null;
    });
  }
  function registerRecv(callback){
    if(registerRecv.child){
      registerRecv.child.stdout.removeListener("data", dataHandler);
      registerRecv.child.kill();
      registerRecv.child = null;
    }
    registerRecv.child = spawn('java', ['-classpath', './lib/smgpapi20100109.jar', 'Sample.ReceiveSms'].concat(combineConfig(config).split(" ")));
    var dataHandler = function(data){
      console.log("received: " + data);
      callback(data.toString());
    };
    registerRecv.child.stdout.on('data', dataHandler);
  }

  window.SMGP = {
    send : sendMessage,
    recv : registerRecv,
    chooseAccount : chooseAccount
  };

  var gui = require('nw.gui'),
      win = gui.Window.get();
  //win.showDevTools();

  // 关闭接受进程
  win.on("close", function(){
    if(registerRecv.child){
      registerRecv.child.kill();
    }
    this.close(true);
  });

  // 显示窗口
  win.on("loaded", function(){
    win.show();
    win.resizeTo(document.body.offsetWidth, document.body.offsetHeight + 10);
    win.resizeTo(document.body.offsetWidth, document.body.offsetHeight);
  });

  win.setResizable(false);

  // disable drag url
  document.addEventListener("dragstart", function(e){
    if(e.target.nodeName === "A"){
      e.preventDefault();
    }
  }, false);
})();