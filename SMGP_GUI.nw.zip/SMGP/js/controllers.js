'use strict';

/* Controllers */

angular.module('myApp.controllers', []).
  controller('MainCtrl', ['$scope', function($scope) {
    window.scope = $scope;
    $scope.messages = [];
    $scope.phone = "phone1";
    $scope.login = function(e){
      e.target.setAttribute("disabled", true);
      e.target.innerHTML = "已登录";
      e.target.classList.add("btn-success");
      document.getElementById("select-phone").setAttribute("disabled", true);
      SMGP.chooseAccount($scope.phone);
      SMGP.recv(function(data){
        try{
          var msg = JSON.parse(data);
          msg.RecvTime = msg.RecvTime.substr(0, 4) + "-" + msg.RecvTime.substr(4, 2) + "-" + msg.RecvTime.substr(6, 2) + " " + msg.RecvTime.substr(8, 2) + ":" + msg.RecvTime.substr(10, 2);
          $scope.messages.push(msg);
          $scope.$digest();
        } catch(e) {
          console.error(e);
          console.log("error data: " + data);
        }
      });
    };
    $scope.send = function(){
      if($scope.textSend){
        $scope.toNumber = document.getElementById("toNumber").value;
        SMGP.send($scope.textSend, $scope.toNumber);
        $scope.textSend = "";
      }
    };
    $scope.newPhone = function(){
      window.open("index.html");
    };
    $scope.closeWindow = function(){
      require("nw.gui").Window.get().close();
    };

  }]);